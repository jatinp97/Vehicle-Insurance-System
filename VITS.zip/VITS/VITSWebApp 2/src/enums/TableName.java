package enums;

public enum TableName {
Functionality_Mstr,
User_Mstr,
Company_Mstr,
Scheme_Mstr,
Agent_Mstr,
Policy_Mstr	
}
