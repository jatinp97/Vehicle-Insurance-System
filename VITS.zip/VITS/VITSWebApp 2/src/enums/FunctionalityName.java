package enums;

public enum FunctionalityName {


}
