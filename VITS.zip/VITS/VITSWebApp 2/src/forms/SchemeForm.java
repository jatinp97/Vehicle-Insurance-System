package forms;

public class SchemeForm {

	private String schemeName = null;
	private String schemeCompName = null;
	private String schemeCompId = null;
	private String errortext = null;
	
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getSchemeCompName() {
		return schemeCompName;
	}
	public void setSchemeCompName(String schemeCompName) {
		this.schemeCompName = schemeCompName;
	}
	public String getSchemeCompId() {
		return schemeCompId;
	}
	public void setSchemeCompId(String schemeCompId) {
		this.schemeCompId = schemeCompId;
	}
	public String getErrortext() {
		return errortext;
	}
	public void setErrortext(String errortext) {
		this.errortext = errortext;
	}
	
}
