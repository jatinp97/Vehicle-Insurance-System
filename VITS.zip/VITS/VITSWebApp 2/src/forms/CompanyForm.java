package forms;

public class CompanyForm {

	private String companyName = null;
	private String companyAdd = null;
	private String errortext = null;
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyAdd() {
		return companyAdd;
	}
	public void setCompanyAdd(String companyAdd) {
		this.companyAdd = companyAdd;
	}
	public String getErrortext() {
		return errortext;
	}
	public void setErrortext(String errortext) {
		this.errortext = errortext;
	}
	
	
}
