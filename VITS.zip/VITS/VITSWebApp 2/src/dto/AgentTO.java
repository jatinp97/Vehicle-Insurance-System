package dto;


public class AgentTO {

	private Integer agentCode = null;
	private String agentName = null;
	private Integer branchCode = null;
	private String branchName = null;
	private Integer companyId = null;
	private String companyName = null;
	private Integer schemeId = null;
	private String schemeName = null;
	private Integer smCode = null;
	private String smName = null;
	private Integer vendorCode = null;
	private String vendorName = null;
	public Integer getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(Integer agentCode) {
		this.agentCode = agentCode;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public Integer getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(Integer branchCode) {
		this.branchCode = branchCode;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Integer getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(Integer schemeId) {
		this.schemeId = schemeId;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public Integer getSmCode() {
		return smCode;
	}
	public void setSmCode(Integer smCode) {
		this.smCode = smCode;
	}
	public String getSmName() {
		return smName;
	}
	public void setSmName(String smName) {
		this.smName = smName;
	}
	public Integer getVendorCode() {
		return vendorCode;
	}
	public void setVendorCode(Integer vendorCode) {
		this.vendorCode = vendorCode;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	
	
}
