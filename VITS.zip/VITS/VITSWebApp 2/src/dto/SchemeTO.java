package dto;


public class SchemeTO {

	private Integer schemeId = null;
	private String schemeName = null;
	private Integer schemeCompId = null;
	private String schemeCompName = null;
	
	public Integer getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(Integer schemeId) {
		this.schemeId = schemeId;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public Integer getSchemeCompId() {
		return schemeCompId;
	}
	public void setSchemeCompId(Integer schemeCompId) {
		this.schemeCompId = schemeCompId;
	}
	public String getSchemeCompName() {
		return schemeCompName;
	}
	public void setSchemeCompName(String schemeCompName) {
		this.schemeCompName = schemeCompName;
	}
	
	
	
	
	
}
